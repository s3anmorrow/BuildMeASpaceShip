# SpaceshipBuilder
Mobile app targeted for pre-school kids - using HTML5 / CreateJS / Phonegap